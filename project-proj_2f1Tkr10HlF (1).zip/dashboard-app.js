// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black text-white">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload Page</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function LoginStep({ onLogin }) {
    const [mobile, setMobile] = React.useState('');
    const [otp, setOtp] = React.useState('');
    const [step, setStep] = React.useState('mobile'); 
    const [loading, setLoading] = React.useState(false);

    const handleSendOtp = (e) => {
        e.preventDefault();
        setLoading(true);
        // Simulate OTP send
        setTimeout(() => {
            setLoading(false);
            setStep('otp');
            alert(`Simulated OTP sent to ${mobile}. Use '1234' to login.`);
        }, 1500);
    };

    const handleVerifyOtp = (e) => {
        e.preventDefault();
        setLoading(true);
        setTimeout(() => {
            setLoading(false);
            if (otp === '1234') {
                onLogin();
            } else {
                alert('Invalid OTP. Try 1234.');
            }
        }, 1000);
    };

    return (
        <div className="min-h-[70vh] flex items-center justify-center px-4 relative z-10">
            <div className="w-full max-w-md bg-[#121212] border border-[#333] p-10 relative shadow-2xl">
                 <div className="text-center mb-8">
                    <div className="w-16 h-16 bg-[#333] rounded-full flex items-center justify-center mx-auto mb-4 border border-[#00ff88]">
                        <div className="icon-lock text-[#00ff88] text-2xl"></div>
                    </div>
                    <h2 className="text-3xl font-black uppercase text-white">Client Portal</h2>
                    <p className="text-gray-500 text-sm">Secure Access Area</p>
                </div>

                {step === 'mobile' ? (
                    <form onSubmit={handleSendOtp} className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-xs uppercase font-bold text-[#00ff88]">Mobile Number</label>
                            <input 
                                type="tel" 
                                value={mobile}
                                onChange={(e) => setMobile(e.target.value)}
                                className="input-field text-center text-xl tracking-widest" 
                                placeholder="+91 XXXXX XXXXX" 
                                required 
                            />
                        </div>
                        <button type="submit" className="btn btn-primary w-full" disabled={loading}>
                            {loading ? 'Sending OTP...' : 'Get Access Code'}
                        </button>
                    </form>
                ) : (
                    <form onSubmit={handleVerifyOtp} className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-xs uppercase font-bold text-[#00ff88]">Enter OTP</label>
                            <input 
                                type="text" 
                                value={otp}
                                onChange={(e) => setOtp(e.target.value)}
                                className="input-field text-center text-xl tracking-[1em]" 
                                placeholder="XXXX" 
                                maxLength="4"
                                required 
                            />
                        </div>
                        <button type="submit" className="btn btn-primary w-full" disabled={loading}>
                            {loading ? 'Verifying...' : 'Unlock Dashboard'}
                        </button>
                        <button 
                            type="button"
                            onClick={() => setStep('mobile')}
                            className="w-full text-xs text-gray-500 hover:text-white uppercase mt-4 underline"
                        >
                            Change Number
                        </button>
                    </form>
                )}
            </div>
        </div>
    );
}

function DashboardView({ onLogout }) {
    // ... (Chart logic remains similar, simplified for display)
     const chartRef = React.useRef(null);

    React.useEffect(() => {
        if (chartRef.current) {
            const ctx = chartRef.current.getContext('2d');
            new ChartJS(ctx, {
                type: 'line',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Impressions',
                        data: [1200, 1900, 3000, 5000, 4800, 6000, 8500],
                        borderColor: '#00ff88',
                        backgroundColor: 'rgba(0, 255, 136, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { grid: { color: '#333' }, ticks: { color: '#888' } },
                        x: { grid: { display: false }, ticks: { color: '#888' } }
                    }
                }
            });
        }
    }, []);

    return (
        <div className="container mx-auto px-4 py-8">
            <header className="flex justify-between items-center mb-12 border-b border-[#333] pb-6">
                <div>
                    <h1 className="text-2xl font-black uppercase">Dashboard</h1>
                    <div className="flex items-center space-x-2 mt-1">
                        <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                        <span className="text-xs text-gray-400 font-mono">LIVE SESSION</span>
                    </div>
                </div>
                <button onClick={onLogout} className="btn border-red-500 text-red-500 hover:bg-red-500 px-4 py-2 text-xs">Logout</button>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Main Stats */}
                <div className="lg:col-span-2 space-y-8">
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-[#121212] p-6 border-l-4 border-[#00ff88]">
                            <div className="text-xs text-gray-500 uppercase">Ad Spend</div>
                            <div className="text-2xl font-mono text-white">$2,450</div>
                        </div>
                        <div className="bg-[#121212] p-6 border-l-4 border-blue-500">
                            <div className="text-xs text-gray-500 uppercase">ROAS</div>
                            <div className="text-2xl font-mono text-white">4.2x</div>
                        </div>
                        <div className="bg-[#121212] p-6 border-l-4 border-purple-500">
                            <div className="text-xs text-gray-500 uppercase">CTR</div>
                            <div className="text-2xl font-mono text-white">3.1%</div>
                        </div>
                     </div>
                     
                     <div className="bg-[#121212] border border-[#333] p-6 h-80">
                         <canvas ref={chartRef}></canvas>
                     </div>
                </div>
                
                {/* Tools & Notifications */}
                <div className="space-y-8">
                    <div className="bg-[#121212] border border-[#333] p-6">
                        <h3 className="text-sm font-bold uppercase mb-4 text-[#00ff88]">AI Tool Suite</h3>
                        <div className="grid grid-cols-2 gap-2">
                             {['Copy Gen', 'Trend Spy', 'Hashtag AI', 'Script Writer', 'Audit', 'Competitor'].map((t,i) => (
                                 <div key={i} className="bg-black p-2 text-center text-xs border border-[#333] hover:border-[#00ff88] cursor-pointer transition-colors">
                                     {t}
                                 </div>
                             ))}
                        </div>
                    </div>
                    
                     <div className="bg-[#121212] border border-[#333] p-6">
                        <h3 className="text-sm font-bold uppercase mb-4 text-gray-400">Notifications</h3>
                        <div className="space-y-3">
                            <div className="text-xs text-gray-500 border-b border-[#333] pb-2">New campaign launched successfully.</div>
                            <div className="text-xs text-gray-500 border-b border-[#333] pb-2">Weekly report available for download.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

function DashboardApp() {
    const [isLoggedIn, setIsLoggedIn] = React.useState(false);

    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <NativeAds />
            <Navigation activePage="dashboard" />
            
            {isLoggedIn ? (
                <DashboardView onLogout={() => setIsLoggedIn(false)} />
            ) : (
                <LoginStep onLogin={() => setIsLoggedIn(true)} />
            )}
            
            {!isLoggedIn && <Footer />}
            <ChatBot />
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <DashboardApp />
  </ErrorBoundary>
);