When displaying availability for Social Media Management:
- Explicitly mention: "Student Schedule: Available Weekdays after 6:00 PM | Weekends Flexible"
- Do not promise availability during school hours (10 AM - 4 PM) or tuition hours (4:30 PM - 6 PM).