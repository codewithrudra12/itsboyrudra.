# Rudraksh Sharma Portfolio Project

## Overview
A raw-layout, dark-themed portfolio website for Rudraksh Sharma, featuring services for Meta Ads and YouTube Thumbnails.

## Pages
- **Home**: Hero slider, service overviews, testimonials.
- **Services**: Detailed pricing tables for Meta Ads and Thumbnails.
- **Portfolio**: Owner profile and work showcase.
- **Contact**: Contact form, Calendly integration, social links.
- **Blog**: Article listings.
- **Dashboard**: Client portal simulation.

## Key Features
- Dark Mode / Raw Aesthetic.
- Formspree integration for forms.
- PayPal integration for payments.
- Animated Hero section.