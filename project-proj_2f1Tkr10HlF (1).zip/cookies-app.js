function CookiesApp() {
    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <NativeAds />
            <Navigation activePage="home" />
            <div className="container mx-auto px-4 md:px-6 py-20 max-w-4xl">
                <h1 className="text-4xl font-black uppercase mb-8 text-[#00ff88]">Cookies Policy</h1>
                <div className="space-y-6 text-gray-300">
                    <p>This site uses cookies to enhance your experience.</p>
                    <h2 className="text-xl font-bold text-white mt-8">What are cookies?</h2>
                    <p>Cookies are small text files stored on your device that help us remember your preferences.</p>
                    <h2 className="text-xl font-bold text-white mt-8">How we use them</h2>
                    <p>We use cookies for analytics (to understand how you use our site) and functionality (like remembering your login status).</p>
                </div>
            </div>
            <ChatBot />
            <ScrollToTop />
            <Footer />
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<CookiesApp />);