function TermsApp() {
    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <Navigation activePage="home" />
            <div className="container mx-auto px-4 md:px-6 py-20 max-w-4xl">
                <h1 className="text-4xl font-black uppercase mb-8 text-[#00ff88]">Terms of Use</h1>
                <div className="space-y-6 text-gray-300">
                    <p>Last updated: January 2026</p>
                    <h2 className="text-xl font-bold text-white mt-8">1. Acceptance of Terms</h2>
                    <p>By accessing and using this website, you accept and agree to be bound by the terms and provision of this agreement. In addition, when using these particular services, you shall be subject to any posted guidelines or rules applicable to such services.</p>
                    
                    <h2 className="text-xl font-bold text-white mt-8">2. Services Description</h2>
                    <p>Rudraksh Sharma provides digital marketing services including but not limited to Meta Ads management, strategy consultation, and YouTube thumbnail design. All services are subject to availability and acceptance of your project. We reserve the right to refuse service to anyone for any reason at any time.</p>
                    
                    <h2 className="text-xl font-bold text-white mt-8">3. Payments & Fees</h2>
                    <p>Payments are processed securely via PayPal or other designated payment gateways. Full payment or an agreed-upon retainer is required before any work commences. Prices for our products and services are subject to change without notice.</p>
                    
                    <h2 className="text-xl font-bold text-white mt-8">4. Intellectual Property</h2>
                    <p>Upon full payment, rights to final designs and creative assets are transferred to the client. However, we retain the right to showcase any work created in our portfolio, social media, and marketing materials unless a specific Non-Disclosure Agreement (NDA) has been signed.</p>
                    
                    <h2 className="text-xl font-bold text-white mt-8">5. Limitation of Liability</h2>
                    <p>In no event shall Rudraksh Sharma, nor any of his officers, directors and employees, be liable to you for anything arising out of or in any way connected with your use of this Website, whether such liability is under contract, tort or otherwise. We do not guarantee specific results (ROAS, CTR, etc.) as these depend on market variables outside our control.</p>
                </div>
            </div>
            <Footer />
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<TermsApp />);