function ServiceCard({ title, icon, description, tags, link, isUnavailable }) {
    return (
        <div className={`card group relative overflow-hidden ${isUnavailable ? 'opacity-50 grayscale' : ''}`}>
            {isUnavailable && (
                <div className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-2 py-1 uppercase tracking-wider transform rotate-12">
                    Unavailable
                </div>
            )}
            
            <div className="mb-6 text-[#00ff88] group-hover:scale-110 transition-transform duration-300">
                <div className={icon + " text-4xl"}></div>
            </div>
            
            <h3 className="text-2xl font-bold mb-4">{title}</h3>
            <p className="text-gray-400 mb-6 text-sm leading-relaxed min-h-[80px]">
                {description}
            </p>
            
            <div className="flex flex-wrap gap-2 mb-8">
                {tags.map((tag, i) => (
                    <span key={i} className="text-xs border border-[#333] px-2 py-1 text-gray-500 uppercase">{tag}</span>
                ))}
            </div>
            
            <a 
                href={isUnavailable ? '#' : link} 
                className={`w-full block text-center py-3 border border-[#333] uppercase text-sm font-bold tracking-wider hover:bg-white hover:text-black transition-colors ${isUnavailable ? 'cursor-not-allowed' : ''}`}
            >
                {isUnavailable ? 'Coming Soon' : 'View Plans'}
            </a>
        </div>
    );
}