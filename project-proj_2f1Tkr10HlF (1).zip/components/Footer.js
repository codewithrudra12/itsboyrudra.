function Footer() {
    const [email, setEmail] = React.useState('');
    const [status, setStatus] = React.useState('');

    const handleSubscribe = async (e) => {
        e.preventDefault();
        setStatus('sending');
        
        try {
            const response = await fetch("https://formspree.io/f/mnjjqgdd", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, type: 'newsletter_subscription' })
            });
            
            if (response.ok) {
                setStatus('success');
                setEmail('');
            } else {
                setStatus('error');
            }
        } catch (error) {
            setStatus('error');
        }
    };

    return (
        <footer className="bg-black border-t border-[#333] pt-16 pb-8">
            <div className="container mx-auto px-4 md:px-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
                    <div className="space-y-4">
                        <h3 className="text-2xl font-bold">Rudraksh Sharma</h3>
                        <p className="text-gray-400 text-sm leading-relaxed">
                            Helping businesses scale with Meta Ads and creators grow with high-converting thumbnails.
                        </p>
                    </div>
                    
                    <div>
                        <h4 className="text-lg font-bold mb-6 text-[#00ff88]">Quick Links</h4>
                        <ul className="space-y-3 text-sm text-gray-400">
                            <li><a href="index.html" className="hover:text-white transition-colors">Home</a></li>
                            <li><a href="services.html" className="hover:text-white transition-colors">Services & Pricing</a></li>
                            <li><a href="portfolio.html" className="hover:text-white transition-colors">Portfolio</a></li>
                            <li><a href="blog.html" className="hover:text-white transition-colors">Blog</a></li>
                            <li><a href="contact.html" className="hover:text-white transition-colors">Contact</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="text-lg font-bold mb-6 text-[#00ff88]">Legal</h4>
                        <ul className="space-y-3 text-sm text-gray-400">
                            <li><a href="terms.html" className="hover:text-white transition-colors">Terms of Use</a></li>
                            <li><a href="privacy.html" className="hover:text-white transition-colors">Privacy Policy</a></li>
                            <li><a href="cookies.html" className="hover:text-white transition-colors">Cookies Policy</a></li>
                            <li><a href="refund.html" className="hover:text-white transition-colors">Refund Policy</a></li>
                            <li><a href="disclaimer.html" className="hover:text-white transition-colors">Disclaimer</a></li>
                            <li><a href="faqs.html" className="hover:text-white transition-colors">FAQs</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="text-lg font-bold mb-6 text-[#00ff88]">Newsletter</h4>
                        <p className="text-xs text-gray-400 mb-4">Subscribe to get the latest marketing insights.</p>
                        <form onSubmit={handleSubscribe} className="space-y-2">
                            <input 
                                type="email" 
                                placeholder="Enter your email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                                className="w-full bg-[#121212] border border-[#333] p-2 text-white text-sm focus:border-[#00ff88] outline-none"
                            />
                            <button 
                                type="submit" 
                                disabled={status === 'sending' || status === 'success'}
                                className="w-full bg-[#333] text-white text-xs font-bold uppercase py-2 hover:bg-[#00ff88] hover:text-black transition-colors disabled:opacity-50"
                            >
                                {status === 'sending' ? 'Joining...' : (status === 'success' ? 'Subscribed!' : 'Subscribe')}
                            </button>
                            {status === 'error' && <p className="text-red-500 text-xs">Something went wrong. Try again.</p>}
                        </form>

                        <h4 className="text-lg font-bold mt-8 mb-4 text-[#00ff88] uppercase">Social Medias</h4>
                        <div className="flex flex-wrap gap-4">
                            <a href="https://www.facebook.com/itsboyrudra" target="_blank" className="w-8 h-8 rounded-full border border-gray-600 flex items-center justify-center hover:border-[#00ff88] hover:text-[#00ff88] transition-all">
                                <div className="icon-facebook text-sm"></div>
                            </a>
                            <a href="https://www.instagram.com/itsboyrudra/?hl=en" target="_blank" className="w-8 h-8 rounded-full border border-gray-600 flex items-center justify-center hover:border-[#00ff88] hover:text-[#00ff88] transition-all">
                                <div className="icon-instagram text-sm"></div>
                            </a>
                             <a href="https://x.com/Itsboyrudra" target="_blank" className="w-8 h-8 rounded-full border border-gray-600 flex items-center justify-center hover:border-[#00ff88] hover:text-[#00ff88] transition-all">
                                <div className="icon-twitter text-sm"></div>
                            </a>
                            <a href="https://www.youtube.com/@Itsboyrudra" target="_blank" className="w-8 h-8 rounded-full border border-gray-600 flex items-center justify-center hover:border-[#00ff88] hover:text-[#00ff88] transition-all">
                                <div className="icon-youtube text-sm"></div>
                            </a>
                            <a href="https://www.linkedin.com/in/rudraksh-sharma-2894b9354/" target="_blank" className="w-8 h-8 rounded-full border border-gray-600 flex items-center justify-center hover:border-[#00ff88] hover:text-[#00ff88] transition-all">
                                <div className="icon-linkedin text-sm"></div>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div className="border-t border-[#333] pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
                    <p>&copy; 2026 Rudraksh Sharma. All rights reserved.</p>
                    <p>Designed with Raw Aesthetics.</p>
                </div>
            </div>
        </footer>
    );
}