function NativeAds() {
    const [currentAd, setCurrentAd] = React.useState(0);
    const ads = [
        "🔥 Limited Time: Get 20% off your first Thumbnail Pack!",
        "🚀 Meta Ads Strategy Call - Free for first-time clients!",
        "⚡ Need urgent designs? We offer 12-hour delivery options.",
        "📈 Check out our new 'Enterprise' scaling package."
    ];

    React.useEffect(() => {
        const interval = setInterval(() => {
            setCurrentAd(prev => (prev + 1) % ads.length);
        }, 5000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="bg-gradient-to-r from-black via-[#121212] to-black border-y border-[#333] py-2 overflow-hidden">
            <div className="container mx-auto px-4 text-center">
                <div key={currentAd} className="animate-fade-in-up text-xs md:text-sm font-mono text-[#00ff88] tracking-widest uppercase">
                    {ads[currentAd]}
                </div>
            </div>
            <style jsx>{`
                @keyframes fadeInUp {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in-up {
                    animation: fadeInUp 0.5s ease-out;
                }
            `}</style>
        </div>
    );
}