function ChatBot() {
    const [isOpen, setIsOpen] = React.useState(false);
    const [messages, setMessages] = React.useState([]);
    const [input, setInput] = React.useState('');
    const [greeting, setGreeting] = React.useState('');

    // Extensive knowledge base about digital marketing topics
    const knowledgeBase = {
        'facebook ads': "Facebook (Meta) Ads success relies on the 'Triangle of Relevance': Angle, Audience, and Asset. We focus on fixing hooks, reducing click friction, and creating compelling offers.",
        'meta ads': "For Meta Ads in 2026, broad targeting with AI-driven creative testing is king. We recommend CBO for scaling and ABO for testing new concepts.",
        'thumbnails': "High CTR thumbnails use color psychology (red vs green), readable typography, and emotional faces. A pattern interrupt within the thumbnail is crucial.",
        'youtube growth': "YouTube growth is about Search Intent and Retention. We optimize metadata but focus heavily on the first 30 seconds of video retention.",
        'pricing': "Meta Ads services start at $15/hr. Thumbnail designs start at $9. We also offer custom Enterprise packages for scaling brands.",
        'ios updates': "Recent iOS updates require server-side tracking (CAPI) to be set up correctly to prevent data loss. We handle this technical setup for you.",
        'scaling': "To scale past $10k/month, you need to diversify creatives, not just audiences. We use the 3:2:2 testing method to find winners efficiently."
    };

    React.useEffect(() => {
        const hour = new Date().getHours();
        if (hour < 12) setGreeting("Good Morning");
        else if (hour < 18) setGreeting("Good Afternoon");
        else setGreeting("Good Evening");

        setMessages([
            { role: 'bot', text: `Hi, ${hour < 12 ? 'Good Morning' : (hour < 18 ? 'Good Afternoon' : 'Good Evening')}! I'm Rudra's AI Assistant (BETA). I can answer questions about Meta Ads strategy, Thumbnail design, Pricing, or our Blog topics!` }
        ]);
    }, []);

    const handleSend = (e) => {
        e.preventDefault();
        if (!input.trim()) return;

        const userMsg = { role: 'user', text: input };
        setMessages(prev => [...prev, userMsg]);
        setInput('');

        // Enhanced AI response logic
        setTimeout(() => {
            let botResponse = "I can help with that! Please contact Rudra directly for a detailed strategy.";
            const lowerInput = userMsg.text.toLowerCase();
            
            // Check Knowledge Base first
            let foundTopic = false;
            for (const key in knowledgeBase) {
                if (lowerInput.includes(key)) {
                    botResponse = knowledgeBase[key];
                    foundTopic = true;
                    break;
                }
            }

            if (!foundTopic) {
                // Fallback logic
                if (lowerInput.includes('who is') || lowerInput.includes('rudra') || lowerInput.includes('bio')) {
                    botResponse = "Rudraksh Sharma is an expert digital marketer and creative designer based in India. With over 3 years of experience, he specializes in scaling businesses through high-ROAS Meta Ads and boosting creator growth with viral YouTube thumbnails.";
                } 
                else if (lowerInput.includes('cost') || lowerInput.includes('package')) {
                    botResponse = "Our pricing is transparent: Meta Ads start at $15/hour, and high-CTR Thumbnails start at $9/design. Check the Services page for Enterprise options!";
                } 
                else if (lowerInput.includes('contact') || lowerInput.includes('email') || lowerInput.includes('phone')) {
                    botResponse = "You can call Rudra directly at +91 78783 83739 or email info.itsboyrudra@gmail.com. Use the quick buttons below!";
                }
                else if (lowerInput.includes('blog') || lowerInput.includes('article')) {
                    botResponse = "We have articles on Meta Ads, YouTube Strategy, and Social Growth. Check out the Blog page for deep dives!";
                }
                else if (lowerInput.match(/[\d\+\-\*\/]/) && (lowerInput.includes('+') || lowerInput.includes('-') || lowerInput.includes('*') || lowerInput.includes('/'))) {
                    try {
                        if (/^[0-9+\-*/.\s()]+$/.test(lowerInput)) {
                            // eslint-disable-next-line no-eval
                            const result = eval(lowerInput); 
                            botResponse = `The result is ${result}. Calculating ROAS? Our Pro plan optimizes every dollar!`;
                        }
                    } catch (e) { /* ignore */ }
                }
                else if (lowerInput.includes('hello') || lowerInput.includes('hi')) {
                    botResponse = "Hello! Ready to scale your business today?";
                }
            }

            setMessages(prev => [...prev, { role: 'bot', text: botResponse }]);
        }, 800);
    };

    const quickAction = (type) => {
        if (type === 'call') window.open('tel:+917878383739');
        if (type === 'email') window.open('mailto:info.itsboyrudra@gmail.com');
    };

    return (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
            {isOpen && (
                <div className="mb-4 w-80 bg-[#121212] border border-[#00ff88] rounded-lg shadow-[0_0_30px_rgba(0,255,136,0.2)] overflow-hidden flex flex-col h-[500px]">
                    <div className="bg-[#00ff88] p-4 flex justify-between items-center">
                        <div className="flex items-center text-black font-bold">
                            <div className="icon-bot mr-2"></div> AI Assistant <span className="text-[10px] bg-black text-white px-1 rounded ml-2">BETA</span>
                        </div>
                        <button onClick={() => setIsOpen(false)} className="text-black hover:bg-black/10 rounded p-1">
                            <div className="icon-x"></div>
                        </button>
                    </div>
                    
                    <div className="flex-1 p-4 overflow-y-auto space-y-4">
                        {messages.map((msg, i) => (
                            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-[85%] p-3 rounded-lg text-sm leading-relaxed ${msg.role === 'user' ? 'bg-[#333] text-white rounded-br-none' : 'bg-[#00ff88]/10 text-[#00ff88] border border-[#00ff88]/20 rounded-bl-none'}`}>
                                    {msg.text}
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="p-4 border-t border-[#333] bg-black">
                         <div className="flex gap-2 mb-3">
                            <button onClick={() => quickAction('call')} className="flex-1 bg-[#333] hover:bg-[#00ff88] hover:text-black text-xs py-2 rounded transition-colors flex items-center justify-center gap-1 font-bold uppercase">
                                <div className="icon-phone h-3 w-3"></div> Call Now
                            </button>
                            <button onClick={() => quickAction('email')} className="flex-1 bg-[#333] hover:bg-[#00ff88] hover:text-black text-xs py-2 rounded transition-colors flex items-center justify-center gap-1 font-bold uppercase">
                                <div className="icon-mail h-3 w-3"></div> Send Email
                            </button>
                        </div>
                        <form onSubmit={handleSend} className="flex gap-2">
                            <input 
                                type="text" 
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                placeholder="Ask about Meta Ads, Pricing..."
                                className="flex-1 bg-[#121212] border border-[#333] rounded px-3 py-2 text-sm text-white focus:border-[#00ff88] outline-none"
                            />
                            <button type="submit" className="bg-[#00ff88] text-black p-2 rounded hover:bg-[#00cc6a]">
                                <div className="icon-send"></div>
                            </button>
                        </form>
                    </div>
                </div>
            )}
            
            <button 
                onClick={() => setIsOpen(!isOpen)}
                className="w-14 h-14 bg-black border-2 border-[#00ff88] rounded-full flex items-center justify-center text-[#00ff88] shadow-lg hover:scale-110 transition-transform group"
            >
                {isOpen ? <div className="icon-x text-2xl"></div> : <div className="icon-message-circle text-2xl group-hover:animate-pulse"></div>}
            </button>
        </div>
    );
}