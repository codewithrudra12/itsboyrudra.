function TestimonialCard({ name, role, quote, image, rating = 5 }) {
    return (
        <div className="bg-[#121212] border border-[#333] p-8 relative h-full flex flex-col hover:border-[#00ff88] transition-colors duration-300">
            <div className="text-6xl text-[#00ff88] opacity-20 absolute top-4 right-4 font-serif">"</div>
            
            <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                    <div key={i} className={`icon-star w-4 h-4 ${i < rating ? 'text-[#00ff88] fill-[#00ff88]' : 'text-gray-600'}`}></div>
                ))}
            </div>

            <p className="text-gray-300 mb-8 relative z-10 italic leading-relaxed flex-grow">
                {quote}
            </p>
            
            <div className="flex items-center mt-auto">
                <div className="w-12 h-12 rounded-full mr-4 overflow-hidden border border-[#333]">
                    <img src={image} alt={name} className="w-full h-full object-cover" />
                </div>
                <div>
                    <h4 className="font-bold text-sm text-white uppercase">{name}</h4>
                    <p className="text-xs text-gray-500 uppercase tracking-wider">{role}</p>
                </div>
            </div>
        </div>
    );
}