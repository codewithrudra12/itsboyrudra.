function ScrollToTop() {
    const [isVisible, setIsVisible] = React.useState(false);

    React.useEffect(() => {
        const toggleVisibility = () => {
            // Show button when page is scrolled down
            if (window.pageYOffset > 300) {
                setIsVisible(true);
            } else {
                setIsVisible(false);
            }
            
            // Also show when near footer (logic handled by scroll position usually covers this)
        };

        window.addEventListener("scroll", toggleVisibility);
        return () => window.removeEventListener("scroll", toggleVisibility);
    }, []);

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };

    if (!isVisible) return null;

    return (
        <button 
            onClick={scrollToTop}
            className="fixed bottom-24 right-6 z-40 bg-[#333] text-white w-10 h-10 rounded hover:bg-[#00ff88] hover:text-black transition-all flex items-center justify-center opacity-80 hover:opacity-100"
            aria-label="Scroll to top"
        >
            <div className="icon-arrow-up"></div>
        </button>
    );
}