function Security() {
    const [contextMenu, setContextMenu] = React.useState({ visible: false, x: 0, y: 0 });

    React.useEffect(() => {
        const handleContextMenu = (e) => {
            e.preventDefault();
            setContextMenu({
                visible: true,
                x: e.pageX,
                y: e.pageY
            });
        };

        const handleClick = () => {
            if (contextMenu.visible) {
                setContextMenu({ ...contextMenu, visible: false });
            }
        };

        const handleKeyDown = (e) => {
            if (e.key === 'F12' || e.keyCode === 123) e.preventDefault();
            if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C')) e.preventDefault();
            if (e.ctrlKey && e.key === 'U') e.preventDefault();
        };

        document.addEventListener('contextmenu', handleContextMenu);
        document.addEventListener('click', handleClick);
        document.addEventListener('keydown', handleKeyDown);

        return () => {
            document.removeEventListener('contextmenu', handleContextMenu);
            document.removeEventListener('click', handleClick);
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [contextMenu]);

    return (
        <>
            {contextMenu.visible && (
                <div 
                    className="fixed z-[100] bg-[#1a1a1a] border border-[#00ff88] text-white py-2 rounded shadow-[0_0_20px_rgba(0,255,136,0.2)] min-w-[200px]"
                    style={{ top: contextMenu.y, left: contextMenu.x }}
                >
                    <div className="px-4 py-2 hover:bg-[#00ff88] hover:text-black cursor-pointer text-sm font-bold uppercase transition-colors" onClick={() => window.location.reload()}>
                        <div className="flex items-center gap-2"><div className="icon-refresh-ccw w-4 h-4"></div> Reload Page</div>
                    </div>
                    <div className="px-4 py-2 hover:bg-[#00ff88] hover:text-black cursor-pointer text-sm font-bold uppercase transition-colors" onClick={() => window.history.back()}>
                        <div className="flex items-center gap-2"><div className="icon-arrow-left w-4 h-4"></div> Back</div>
                    </div>
                    <div className="h-px bg-[#333] my-1"></div>
                    <div className="px-4 py-2 hover:bg-[#00ff88] hover:text-black cursor-pointer text-sm font-bold uppercase transition-colors" onClick={() => window.location.href='roi-calculator.html'}>
                        <div className="flex items-center gap-2"><div className="icon-calculator w-4 h-4"></div> ROI Tool</div>
                    </div>
                    <div className="h-px bg-[#333] my-1"></div>
                    <div className="px-4 py-2 hover:bg-[#00ff88] hover:text-black cursor-pointer text-sm font-bold uppercase transition-colors" onClick={() => window.location.href='contact.html'}>
                        <div className="flex items-center gap-2"><div className="icon-mail w-4 h-4"></div> Contact Creator</div>
                    </div>
                </div>
            )}
        </>
    );
}