function HeroSlider() {
    const [isPlaying, setIsPlaying] = React.useState(true);
    const [currentSlide, setCurrentSlide] = React.useState(0);
    
    const slides = [
        {
            title: "Scale Your Business",
            subtitle: "Expert Meta Ads Management",
            bgClass: "from-blue-900 to-black"
        },
        {
            title: "Viral Thumbnails",
            subtitle: "High CTR Designs for Creators",
            bgClass: "from-purple-900 to-black"
        },
        {
            title: "Raw Aesthetics",
            subtitle: "Unique Digital Experiences",
            bgClass: "from-green-900 to-black"
        }
    ];

    React.useEffect(() => {
        let interval;
        if (isPlaying) {
            interval = setInterval(() => {
                setCurrentSlide((prev) => (prev + 1) % slides.length);
            }, 4000);
        }
        return () => clearInterval(interval);
    }, [isPlaying]);

    return (
        <div className="relative h-screen flex overflow-hidden">
            {/* Sidebar in Hero (as requested) */}
            <div className="hidden lg:flex w-24 border-r border-[#333] flex-col justify-center items-center space-y-8 z-20 bg-black/50 backdrop-blur-sm">
                <div className="rotate-90 text-xs tracking-[0.3em] text-gray-500 whitespace-nowrap">RUDRAKSH SHARMA</div>
                <div className="w-px h-24 bg-[#333]"></div>
                <div className="flex flex-col space-y-6">
                    <a href="https://www.facebook.com/itsboyrudra" target="_blank" className="text-gray-400 hover:text-[#00ff88] transition-colors"><div className="icon-facebook"></div></a>
                    <a href="https://www.instagram.com/itsboyrudra/?hl=en" target="_blank" className="text-gray-400 hover:text-[#00ff88] transition-colors"><div className="icon-instagram"></div></a>
                    <a href="https://www.linkedin.com/in/rudraksh-sharma-2894b9354/" target="_blank" className="text-gray-400 hover:text-[#00ff88] transition-colors"><div className="icon-linkedin"></div></a>
                </div>
            </div>

            {/* Main Hero Content */}
            <div className="flex-1 relative">
                {slides.map((slide, index) => (
                    <div 
                        key={index}
                        className={`absolute inset-0 bg-gradient-to-br ${slide.bgClass} transition-opacity duration-1000 flex items-center justify-center ${currentSlide === index ? 'opacity-100' : 'opacity-0'}`}
                    >
                        <div className="container px-4 text-center z-10">
                            <h2 className="text-[#00ff88] tracking-widest text-sm mb-4 animate-bounce">WELCOME TO THE FUTURE</h2>
                            <h1 className="text-5xl md:text-8xl font-black mb-6 uppercase tracking-tighter leading-none transform transition-transform duration-700 hover:scale-105">
                                {slide.title}
                            </h1>
                            <p className="text-xl md:text-2xl text-gray-300 mb-10 font-light max-w-2xl mx-auto">
                                {slide.subtitle}
                            </p>
                            <div className="flex justify-center gap-4">
                                <a href="services.html" className="btn btn-primary">Explore Services</a>
                                <a href="portfolio.html" className="btn">View Work</a>
                            </div>
                        </div>
                    </div>
                ))}
                
                {/* Overlay Grid Texture */}
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 pointer-events-none"></div>
                
                {/* Controls */}
                <div className="absolute bottom-10 right-10 flex items-center space-x-4 z-20">
                    <button 
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-black transition-all"
                    >
                        {isPlaying ? <div className="icon-pause"></div> : <div className="icon-play"></div>}
                    </button>
                    <div className="flex space-x-2">
                        {slides.map((_, idx) => (
                            <button 
                                key={idx}
                                onClick={() => setCurrentSlide(idx)}
                                className={`w-2 h-2 rounded-full ${currentSlide === idx ? 'bg-[#00ff88]' : 'bg-gray-600'}`}
                            ></button>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}