function CookieConsent() {
    const [isVisible, setIsVisible] = React.useState(false);

    React.useEffect(() => {
        const consent = localStorage.getItem('cookieConsent');
        if (!consent) {
            // Small delay for better UX
            const timer = setTimeout(() => setIsVisible(true), 1000);
            return () => clearTimeout(timer);
        }
    }, []);

    const handleAccept = () => {
        localStorage.setItem('cookieConsent', 'true');
        setIsVisible(false);
    };

    if (!isVisible) return null;

    return (
        <div className="fixed bottom-0 left-0 right-0 z-[80] bg-[#121212] border-t border-[#00ff88] p-6 animate-in slide-in-from-bottom duration-500 shadow-[0_-10px_40px_rgba(0,0,0,0.8)]">
            <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex-1">
                    <h4 className="text-[#00ff88] font-bold uppercase mb-2 flex items-center gap-2">
                        <div className="icon-cookie"></div> Cookie Policy
                    </h4>
                    <p className="text-gray-400 text-sm leading-relaxed max-w-2xl">
                        We use cookies to enhance your experience, analyze site traffic, and serve personalized content. By continuing to use our site, you agree to our use of cookies.
                        <a href="cookies.html" className="text-white underline ml-2 hover:text-[#00ff88]">Read Policy</a>
                    </p>
                </div>
                <div className="flex gap-4 w-full md:w-auto">
                    <button 
                        onClick={handleAccept}
                        className="btn btn-primary whitespace-nowrap flex-1 md:flex-none"
                    >
                        Accept All
                    </button>
                    <button 
                        onClick={() => setIsVisible(false)}
                        className="btn whitespace-nowrap flex-1 md:flex-none"
                    >
                        Decline
                    </button>
                </div>
            </div>
        </div>
    );
}