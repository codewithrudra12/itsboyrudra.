function Navigation({ activePage }) {
    const [isOpen, setIsOpen] = React.useState(false);
    
    const links = [
        { name: 'Home', href: 'index.html' },
        { name: 'Services', href: 'services.html' },
        { name: 'Thumbnails', href: 'thumbnails.html' },
        { name: 'Portfolio', href: 'portfolio.html' },
        { name: 'Resume', href: 'resume.html' },
        { name: 'Blog', href: 'blog.html' },
        { name: 'Contact', href: 'contact.html' }
    ];

    return (
        <nav className="fixed top-0 left-0 w-full z-50 bg-[#050505]/90 backdrop-blur-md border-b border-[#333]">
            <div className="container mx-auto px-4 md:px-6">
                <div className="flex justify-between items-center h-20">
                    <a href="index.html" className="text-2xl font-bold tracking-tighter hover:text-[#00ff88] transition-colors">
                        RUDRAKSH<span className="text-[#00ff88]">.</span>
                    </a>
                    
                    {/* Desktop Menu */}
                    <div className="hidden md:flex space-x-6 lg:space-x-8">
                        {links.map((link) => (
                            <a 
                                key={link.name} 
                                href={link.href}
                                className={`text-sm font-medium hover:text-[#00ff88] transition-colors ${activePage === link.name.toLowerCase() ? 'text-[#00ff88]' : 'text-gray-300'}`}
                            >
                                {link.name}
                            </a>
                        ))}
                        <a href="roi-calculator.html" className="text-sm font-medium text-[#00ff88] border border-[#00ff88] px-3 py-1 rounded hover:bg-[#00ff88] hover:text-black transition-colors">
                            ROI Tool
                        </a>
                    </div>

                    {/* Mobile Menu Button */}
                    <button className="md:hidden text-white hover:text-[#00ff88]" onClick={() => setIsOpen(!isOpen)}>
                        <div className={isOpen ? "icon-x text-2xl" : "icon-menu text-2xl"}></div>
                    </button>
                </div>
            </div>

            {/* Mobile Menu */}
            {isOpen && (
                <div className="md:hidden bg-[#050505] border-b border-[#333]">
                    <div className="px-4 py-4 space-y-4">
                        {links.map((link) => (
                            <a 
                                key={link.name} 
                                href={link.href}
                                className="block text-lg font-medium hover:text-[#00ff88] transition-colors"
                            >
                                {link.name}
                            </a>
                        ))}
                        <a href="roi-calculator.html" className="block text-lg font-medium text-[#00ff88]">
                            ROI Calculator
                        </a>
                    </div>
                </div>
            )}
        </nav>
    );
}