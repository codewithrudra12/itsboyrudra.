function MindsetSection() {
    const articles = [
        {
            title: "Obsession with Detail",
            icon: "icon-microscope",
            content: "We don't believe in 'good enough'. Every pixel, every frame, and every line of copy is scrutinized. Why? Because the subconscious mind notices what the conscious mind misses. The difference between a 2% and 4% CTR is often buried in the details nobody else cares about."
        },
        {
            title: "Data Over Ego",
            icon: "icon-chart-bar",
            content: "We have no emotional attachment to our ideas. If the data says it's not working, we kill it. Immediately. Our loyalty is to the ROAS, not our artistic pride. We test ruthlessly, fail fast, and double down on the winners."
        },
        {
            title: "Speed is a Feature",
            icon: "icon-zap",
            content: "In the digital age, speed isn't just a logistical advantage; it's a competitive moat. We ship fast. We iterate daily. While competitors are still holding meetings about the next campaign, we have already tested 10 variations and found the winner."
        }
    ];

    return (
        <section className="py-24 border-b border-[#333] bg-[#080808]">
            <div className="container mx-auto px-4 md:px-6">
                <div className="mb-16 md:flex justify-between items-end">
                    <div>
                        <h2 className="text-[#00ff88] mb-2 tracking-widest text-sm">Our Philosophy</h2>
                        <h3 className="text-4xl md:text-5xl font-black uppercase">The Mindset</h3>
                    </div>
                    <div className="hidden md:block w-1/3 h-px bg-[#333] mb-4"></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {articles.map((article, index) => (
                        <div key={index} className="group bg-[#121212] border border-[#333] p-8 hover:border-[#00ff88] transition-all duration-300 hover:-translate-y-2">
                            <div className="w-12 h-12 bg-black border border-[#333] flex items-center justify-center mb-6 group-hover:border-[#00ff88] transition-colors">
                                <div className={`${article.icon} text-[#00ff88] text-xl`}></div>
                            </div>
                            <h4 className="text-xl font-bold uppercase mb-4 text-white group-hover:text-[#00ff88] transition-colors">
                                {article.title}
                            </h4>
                            <p className="text-gray-400 text-sm leading-relaxed font-serif">
                                {article.content}
                            </p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}