function CalendlyPopup() {
    const [isVisible, setIsVisible] = React.useState(false);

    React.useEffect(() => {
        // Show popup after 5 seconds or based on some trigger.
        const timer = setTimeout(() => {
            const hasSeen = localStorage.getItem('hasSeenCalendlyPopup');
            if (!hasSeen) {
                setIsVisible(true);
            }
        }, 5000); 
        return () => clearTimeout(timer);
    }, []);

    const closePopup = () => {
        setIsVisible(false);
        localStorage.setItem('hasSeenCalendlyPopup', 'true');
    };

    const openCalendly = () => {
        window.open('https://calendly.com/rudrakshrawla22122008/30min', '_blank');
        closePopup();
    };

    if (!isVisible) return (
        <button 
            onClick={() => setIsVisible(true)}
            className="fixed bottom-6 left-6 z-40 bg-[#00ff88] text-black w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform animate-bounce"
        >
            <div className="icon-phone text-2xl"></div>
        </button>
    );

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <div className="bg-[#121212] border border-[#00ff88] p-8 max-w-md w-full relative shadow-[0_0_30px_rgba(0,255,136,0.3)]">
                <button 
                    onClick={closePopup}
                    className="absolute top-4 right-4 text-gray-400 hover:text-white"
                >
                    <div className="icon-x"></div>
                </button>
                
                <div className="text-center">
                    <div className="w-16 h-16 bg-[#00ff88]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                        <div className="icon-phone-call text-[#00ff88] text-3xl"></div>
                    </div>
                    <h3 className="text-2xl font-bold mb-2">Book a Free 30-min Call</h3>
                    <p className="text-gray-400 mb-8">
                        Let's discuss how we can scale your business with Meta Ads or improve your channel with high-converting thumbnails.
                    </p>
                    <button 
                        onClick={openCalendly}
                        className="btn btn-primary w-full"
                    >
                        Schedule Now
                    </button>
                </div>
            </div>
        </div>
    );
}