// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black text-white">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload Page</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function RoiApp() {
    const [adSpend, setAdSpend] = React.useState(5000);
    const [cpc, setCpc] = React.useState(2.50);
    const [conversionRate, setConversionRate] = React.useState(3.0);
    const [aov, setAov] = React.useState(120);
    
    const barChartRef = React.useRef(null);
    const donutChartRef = React.useRef(null);
    const barChartInstance = React.useRef(null);
    const donutChartInstance = React.useRef(null);

    // Calculations
    const clicks = adSpend / cpc;
    const conversions = clicks * (conversionRate / 100);
    const revenue = conversions * aov;
    const profit = revenue - adSpend;
    const roas = revenue / adSpend;

    React.useEffect(() => {
        if (barChartInstance.current) barChartInstance.current.destroy();
        if (donutChartInstance.current) donutChartInstance.current.destroy();

        const ctxBar = barChartRef.current.getContext('2d');
        const ctxDonut = donutChartRef.current.getContext('2d');

        barChartInstance.current = new ChartJS(ctxBar, {
            type: 'bar',
            data: {
                labels: ['Ad Spend', 'Revenue', 'Profit'],
                datasets: [{
                    label: 'Financials ($)',
                    data: [adSpend, revenue, profit],
                    backgroundColor: ['#333333', '#00ff88', profit > 0 ? '#00cc6a' : '#ef4444'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { grid: { color: '#222' }, ticks: { color: '#888' } },
                    x: { grid: { display: false }, ticks: { color: '#888' } }
                }
            }
        });

        donutChartInstance.current = new ChartJS(ctxDonut, {
            type: 'doughnut',
            data: {
                labels: ['Profit Margin', 'Cost'],
                datasets: [{
                    data: [profit > 0 ? profit : 0, adSpend],
                    backgroundColor: ['#00ff88', '#333333'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { color: '#888' } } },
                cutout: '70%'
            }
        });

    }, [adSpend, cpc, conversionRate, aov, revenue, profit]);

    const handleDownload = () => {
        window.print();
    };

    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <div className="no-print">
                <Navigation activePage="roi" />
            </div>
            
            <header className="py-20 border-b border-[#333] no-print">
                <div className="container mx-auto px-4 md:px-6 text-center">
                    <h1 className="text-5xl md:text-7xl font-black uppercase mb-6 tracking-tighter">
                        ROI <span className="text-[#00ff88]">Calculator</span>
                    </h1>
                    <p className="text-gray-400 max-w-2xl mx-auto text-lg">
                        Advanced forecasting for your ad campaigns. Simulate scenarios and export reports.
                    </p>
                </div>
            </header>

            <section className="py-12">
                <div className="container mx-auto px-4 md:px-6">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                        {/* Inputs */}
                        <div className="lg:col-span-1 space-y-8 bg-[#121212] p-8 border border-[#333] h-fit">
                            <h3 className="text-xl font-bold uppercase mb-4 text-white border-b border-[#333] pb-4">Campaign Inputs</h3>
                            
                            <div>
                                <label className="block text-xs uppercase font-bold text-[#00ff88] mb-2">Total Ad Spend ($)</label>
                                <input type="number" value={adSpend} onChange={e => setAdSpend(Number(e.target.value))} className="input-field text-xl font-bold" />
                                <input type="range" min="100" max="50000" step="100" value={adSpend} onChange={e => setAdSpend(Number(e.target.value))} className="w-full mt-2 accent-[#00ff88]" />
                            </div>

                            <div>
                                <label className="block text-xs uppercase font-bold text-gray-500 mb-2">Avg. Cost Per Click ($)</label>
                                <input type="number" step="0.1" value={cpc} onChange={e => setCpc(Number(e.target.value))} className="input-field" />
                            </div>

                            <div>
                                <label className="block text-xs uppercase font-bold text-gray-500 mb-2">Conversion Rate (%)</label>
                                <input type="number" step="0.1" value={conversionRate} onChange={e => setConversionRate(Number(e.target.value))} className="input-field" />
                            </div>

                            <div>
                                <label className="block text-xs uppercase font-bold text-gray-500 mb-2">Avg. Order Value ($)</label>
                                <input type="number" value={aov} onChange={e => setAov(Number(e.target.value))} className="input-field" />
                            </div>

                             <button onClick={handleDownload} className="btn btn-primary w-full mt-4 no-print">
                                <div className="icon-download mr-2"></div> Download Report (PDF)
                            </button>
                        </div>

                        {/* Visualization */}
                        <div className="lg:col-span-2 space-y-8">
                            {/* Summary Cards */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="bg-[#121212] p-6 border border-[#333]">
                                    <div className="text-gray-500 text-xs uppercase tracking-widest mb-2">Total Clicks</div>
                                    <div className="text-2xl font-black text-white">{Math.round(clicks).toLocaleString()}</div>
                                </div>
                                <div className="bg-[#121212] p-6 border border-[#333]">
                                    <div className="text-gray-500 text-xs uppercase tracking-widest mb-2">Conversions</div>
                                    <div className="text-2xl font-black text-white">{Math.round(conversions).toLocaleString()}</div>
                                </div>
                                <div className="bg-[#121212] p-6 border border-[#333]">
                                    <div className="text-gray-500 text-xs uppercase tracking-widest mb-2">Revenue</div>
                                    <div className="text-2xl font-black text-[#00ff88]">${revenue.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                                </div>
                                <div className="bg-[#121212] p-6 border border-[#333]">
                                    <div className="text-gray-500 text-xs uppercase tracking-widest mb-2">ROAS</div>
                                    <div className="text-2xl font-black text-white">{roas.toFixed(2)}x</div>
                                </div>
                            </div>

                            {/* Charts */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div className="bg-[#121212] p-6 border border-[#333] h-80 chart-container">
                                    <h4 className="text-xs uppercase font-bold text-gray-500 mb-4">Financial Overview</h4>
                                    <canvas ref={barChartRef}></canvas>
                                </div>
                                <div className="bg-[#121212] p-6 border border-[#333] h-80 chart-container">
                                    <h4 className="text-xs uppercase font-bold text-gray-500 mb-4">Profitability Ratio</h4>
                                    <canvas ref={donutChartRef}></canvas>
                                </div>
                            </div>

                            {/* Detailed Table */}
                            <div className="bg-[#121212] border border-[#333] overflow-hidden">
                                <table className="w-full text-left border-collapse">
                                    <thead>
                                        <tr className="bg-black text-xs uppercase text-gray-500">
                                            <th className="p-4 border-b border-[#333]">Metric</th>
                                            <th className="p-4 border-b border-[#333]">Value</th>
                                            <th className="p-4 border-b border-[#333]">Analysis</th>
                                        </tr>
                                    </thead>
                                    <tbody className="text-sm">
                                        <tr>
                                            <td className="p-4 border-b border-[#333] text-gray-300">Net Profit</td>
                                            <td className={`p-4 border-b border-[#333] font-bold ${profit >= 0 ? 'text-[#00ff88]' : 'text-red-500'}`}>${profit.toFixed(2)}</td>
                                            <td className="p-4 border-b border-[#333] text-gray-500">{profit > 0 ? 'Profitable Campaign' : 'Loss Making'}</td>
                                        </tr>
                                        <tr>
                                            <td className="p-4 border-b border-[#333] text-gray-300">CPA (Cost Per Acquisition)</td>
                                            <td className="p-4 border-b border-[#333] text-white">${(adSpend / conversions).toFixed(2)}</td>
                                            <td className="p-4 border-b border-[#333] text-gray-500">Target: &lt; ${aov * 0.3}</td>
                                        </tr>
                                        <tr>
                                            <td className="p-4 text-gray-300">Break-even ROAS</td>
                                            <td className="p-4 text-white">{(1 / (1 - 0.3)).toFixed(2)}x (Est.)</td>
                                            <td className="p-4 text-gray-500">Assuming 30% margin</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <div className="no-print">
                <Footer />
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <RoiApp />
  </ErrorBoundary>
);