// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black text-white">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload Page</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function ContactApp() {
    // Removed Google reCAPTCHA script loading

    const handleCodeInput = (e) => {
        // Allow only numbers
        e.target.value = e.target.value.replace(/[^0-9]/g, '');
    };

    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <Navigation activePage="contact" />
            
            <section className="py-20">
                <div className="container mx-auto px-4 md:px-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
                        {/* Contact Info */}
                        <div>
                            <h2 className="text-[#00ff88] tracking-widest text-sm mb-4">Get In Touch</h2>
                            <h1 className="text-5xl font-black uppercase mb-8 leading-none">
                                Ready to <br/> Scale?
                            </h1>
                            <p className="text-gray-400 mb-12 text-lg">
                                Whether you need high-converting thumbnails or a complete Meta Ads strategy, I'm here to help you crush your goals.
                            </p>
                            
                            <div className="space-y-8">
                                <div className="flex items-start">
                                    <div className="w-12 h-12 bg-[#121212] border border-[#333] flex items-center justify-center mr-6 shrink-0">
                                        <div className="icon-smartphone text-[#00ff88]"></div>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold uppercase text-gray-500 mb-1">WhatsApp / Mobile</h3>
                                        <p className="text-xl font-mono text-white">+91 78783 83739</p>
                                    </div>
                                </div>
                                
                                <div className="flex items-start">
                                    <div className="w-12 h-12 bg-[#121212] border border-[#333] flex items-center justify-center mr-6 shrink-0">
                                        <div className="icon-mail text-[#00ff88]"></div>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold uppercase text-gray-500 mb-1">Email</h3>
                                        <p className="text-xl font-mono text-white">info.itsboyrudra@gmail.com</p>
                                    </div>
                                </div>

                                <div className="flex items-start">
                                    <div className="w-12 h-12 bg-[#121212] border border-[#333] flex items-center justify-center mr-6 shrink-0">
                                        <div className="icon-map-pin text-[#00ff88]"></div>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold uppercase text-gray-500 mb-1">Location</h3>
                                        <p className="text-xl font-mono text-white">Global Remote Service</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Contact Form */}
                        <div className="bg-[#121212] border border-[#333] p-8 md:p-12">
                            <h3 className="text-2xl font-bold uppercase mb-8">Send a Message</h3>
                            
                            <form action="https://formspree.io/f/xgoegpnk" method="POST" className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-xs uppercase text-gray-500 font-bold">Name</label>
                                        <input type="text" name="name" className="input-field" placeholder="YOUR NAME" required />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs uppercase text-gray-500 font-bold">Country</label>
                                        <input type="text" name="country" className="input-field" placeholder="YOUR COUNTRY" required />
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-xs uppercase text-gray-500 font-bold">Mobile</label>
                                    <div className="flex gap-2">
                                        <div className="w-24 relative">
                                            <span className="absolute left-3 top-3 text-gray-500 text-xs font-bold">+</span>
                                            <input 
                                                type="text" 
                                                name="country_code" 
                                                className="input-field pl-6" 
                                                placeholder="91" 
                                                required 
                                                maxLength="4"
                                                onInput={handleCodeInput}
                                            />
                                        </div>
                                        <input type="tel" name="mobile" className="input-field flex-1" placeholder="PHONE NUMBER" required />
                                    </div>
                                    <p className="text-[10px] text-gray-500 text-right">Numbers only for country code</p>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-xs uppercase text-gray-500 font-bold">Email</label>
                                    <input type="email" name="email" className="input-field" placeholder="YOUR EMAIL ADDRESS" required />
                                </div>

                                <div className="space-y-2">
                                    <label className="text-xs uppercase text-gray-500 font-bold">Service Interest</label>
                                    <select name="service" className="input-field appearance-none cursor-pointer">
                                        <option value="meta-ads">Meta Ads Strategy</option>
                                        <option value="thumbnails">YouTube Thumbnails</option>
                                        <option value="smm">Social Media Management</option>
                                        <option value="consultation">General Consultation</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-xs uppercase text-gray-500 font-bold">Message</label>
                                    <textarea name="message" className="input-field h-32 resize-none" placeholder="TELL ME ABOUT YOUR PROJECT..." required></textarea>
                                </div>

                                {/* Removed Google ReCAPTCHA div */}

                                <button type="submit" className="btn btn-primary w-full">Send Message</button>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
            <Footer />
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <ContactApp />
  </ErrorBoundary>
);