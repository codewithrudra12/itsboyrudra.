// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black text-white">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload Page</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function PricingCard({ title, price, target, includes, perfectFor, paymentLink, isPopular, onPurchase, customAction }) {
    return (
        <div className={`relative bg-[#121212] border p-8 flex flex-col h-full transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,255,136,0.1)] ${isPopular ? 'border-[#00ff88] scale-105 z-10' : 'border-[#333] hover:border-[#00ff88]/50'}`}>
            {isPopular && (
                <div className="absolute top-0 right-0 bg-[#00ff88] text-black text-xs font-bold px-3 py-1 uppercase tracking-wider">
                    Recommended
                </div>
            )}
            
            <h3 className="text-2xl font-black uppercase mb-2 text-white">{title}</h3>
            <div className="text-[#00ff88] text-xl font-bold mb-4 font-mono">{price}</div>
            <p className="text-gray-400 text-sm mb-8 border-b border-[#333] pb-6 min-h-[60px]">{target}</p>
            
            <div className="flex-1 mb-8">
                <h4 className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-4">Includes:</h4>
                <ul className="space-y-3">
                    {includes.map((item, i) => (
                        <li key={i} className="flex items-start text-sm text-gray-300">
                            <div className="icon-check text-[#00ff88] mr-3 mt-0.5 shrink-0"></div>
                            <span>{item}</span>
                        </li>
                    ))}
                </ul>
            </div>

            {perfectFor && (
                <div className="mb-8">
                    <h4 className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-4">Perfect For:</h4>
                    <ul className="space-y-2">
                        {perfectFor.map((item, i) => (
                            <li key={i} className="text-sm text-gray-400 flex items-center">
                                <span className="w-1 h-1 bg-gray-500 rounded-full mr-2"></span>
                                {item}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            <div className="mt-auto space-y-3">
                 <button 
                    onClick={() => onPurchase({title, price})}
                    className={`w-full btn ${isPopular ? 'btn-primary' : ''} group`}
                >
                    <span>{customAction || "Purchase Plan"}</span>
                    <div className="icon-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></div>
                </button>
            </div>
        </div>
    );
}

function ServicesApp() {
    const [activeTab, setActiveTab] = React.useState('meta');

    // Redirect to new Payment Page with Params
    const handlePurchase = (plan) => {
        const url = `payment.html?plan=${encodeURIComponent(plan.title)}&price=${encodeURIComponent(plan.price)}`;
        window.location.href = url;
    };

    const metaPlans = [
        {
            title: "Starter",
            price: "$15/hour",
            target: "Small businesses with tiny budgets",
            includes: ["2 ad concepts/hr", "Basic targeting", "3 ad copy variations", "1 visual asset", "48h delivery"],
            perfectFor: ["Local businesses", "Creators"],
        },
        {
            title: "Pro",
            price: "$20/hour",
            target: "Growing businesses with consistent ad spend",
            includes: ["3-4 concepts/hr", "Advanced targeting", "5 ad copy variations", "A/B testing", "Weekly optimization"],
            perfectFor: ["E-commerce", "Agencies"],
            isPopular: true
        },
        {
            title: "Enterprise",
            price: "$29/hour",
            target: "Serious advertisers",
            includes: ["5+ concepts/hr", "Multi-platform strategy", "Full funnel creatives", "Video storyboarding", "Unlimited revisions"],
            perfectFor: ["Scaling brands", "High-ticket"],
        }
    ];

    const thumbnailPlans = [
        {
            title: "Starter",
            price: "$9/thumbnail",
            target: "New YouTubers",
            includes: ["1 concept", "2 revisions", "Standard size", "Basic text overlay", "24-48h delivery"],
        },
        {
            title: "Pro",
            price: "$12/thumbnail",
            target: "Growing channels",
            includes: ["2-3 variations", "5 revisions", "Advanced effects", "12-24h delivery", "CTR prediction"],
            isPopular: true
        },
        {
            title: "Enterprise",
            price: "$25/thumbnail", 
            target: "Elite Creators",
            includes: ["Unlimited revisions", "Source Files", "3D Elements", "Dedicated Designer", "Priority delivery"],
        }
    ];

    const smmPlans = [
        {
            title: "Starter Plan",
            price: "$50 – $80 / month",
            target: "Best to start",
            includes: ["3 posts/week", "Caption + hashtags", "Basic creatives", "IG or FB", "Weekly scheduling"],
            perfectFor: ["New businesses", "Personal Brands"],
        },
        {
            title: "Growth Plan",
            price: "$90 – $130 / month",
            target: "Accelerated visibility",
            includes: ["4–5 posts/week", "Reels + posts", "IG + FB", "Content planning", "Engagement management"],
            perfectFor: ["Restaurants", "Influencers"],
            isPopular: true
        },
        {
            title: "Custom / Per Post",
            price: "Custom Pricing",
            target: "Flexible requirements",
            includes: ["$5 – $8 per post", "$10 – $15 per Reel", "Custom calendar", "Ad-hoc requests"],
            perfectFor: ["One-off projects"],
            customAction: "Pay Custom Amount"
        }
    ];

    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <NativeAds />
            <Navigation activePage="services" />
            
            <header className="py-20 border-b border-[#333]">
                <div className="container mx-auto px-4 md:px-6 text-center">
                    <h1 className="text-5xl md:text-7xl font-black uppercase mb-6 tracking-tighter">
                        Pricing <span className="text-[#00ff88]">Plans</span>
                    </h1>
                    <p className="text-gray-400 max-w-2xl mx-auto text-lg">
                        Transparent pricing for measurable results. Choose the package that fits your growth stage.
                    </p>
                </div>
            </header>

            <section className="py-16">
                <div className="container mx-auto px-4 md:px-6">
                    {/* Tabs */}
                    <div className="flex justify-center mb-16 overflow-x-auto">
                        <div className="inline-flex border border-[#333] p-1 bg-[#121212] whitespace-nowrap">
                            <button 
                                onClick={() => setActiveTab('meta')}
                                className={`px-4 md:px-8 py-3 text-sm font-bold uppercase tracking-wider transition-all ${activeTab === 'meta' ? 'bg-[#00ff88] text-black' : 'text-gray-400 hover:text-white'}`}
                            >
                                Meta Ads
                            </button>
                            <button 
                                onClick={() => setActiveTab('thumbnails')}
                                className={`px-4 md:px-8 py-3 text-sm font-bold uppercase tracking-wider transition-all ${activeTab === 'thumbnails' ? 'bg-[#00ff88] text-black' : 'text-gray-400 hover:text-white'}`}
                            >
                                Thumbnails
                            </button>
                            <button 
                                onClick={() => setActiveTab('smm')}
                                className={`px-4 md:px-8 py-3 text-sm font-bold uppercase tracking-wider transition-all ${activeTab === 'smm' ? 'bg-[#00ff88] text-black' : 'text-gray-400 hover:text-white'}`}
                            >
                                Social Media
                            </button>
                        </div>
                    </div>

                    {/* SMM Specific Schedule Notice - Updated Asset */}
                    {activeTab === 'smm' && (
                        <div className="max-w-4xl mx-auto mb-12 bg-[#1a1a1a] border border-l-4 border-[#00ff88] p-6 flex flex-col md:flex-row items-center gap-6 animate-in fade-in slide-in-from-top-4">
                            <div className="w-full md:w-1/3 aspect-video overflow-hidden border border-[#333] rounded relative group">
                                <img src="https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/50b4c812-3d55-4e60-876f-7174e3fbd51c.Untitled" alt="SMM Schedule" className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <a href="instagram-dummy.html" className="btn btn-primary text-xs">View Live Example</a>
                                </div>
                            </div>
                            <div className="flex-1 text-left">
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="text-xl font-bold uppercase text-white">Student Availability Notice</h3>
                                    <a href="instagram-dummy.html" className="text-[#00ff88] text-xs font-bold underline">See Work Sample</a>
                                </div>
                                <p className="text-gray-400 text-sm mb-4 leading-relaxed">
                                    I am a dedicated student managing your social growth. My working hours for active management are optimized around my academic schedule (IST) to ensure full focus on your brand.
                                </p>
                                <div className="grid grid-cols-2 gap-4 text-xs font-mono uppercase tracking-wide">
                                    <div className="bg-black p-2 border border-[#333] text-gray-500">
                                        <span className="block text-[#00ff88] font-bold">Weekdays (IST)</span>
                                        Available after 6:00 PM
                                    </div>
                                    <div className="bg-black p-2 border border-[#333] text-gray-500">
                                        <span className="block text-[#00ff88] font-bold">Weekends</span>
                                        Flexible Hours
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Content */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                        {activeTab === 'meta' && metaPlans.map((plan, i) => (
                            <PricingCard key={i} {...plan} onPurchase={handlePurchase} />
                        ))}
                        {activeTab === 'thumbnails' && thumbnailPlans.map((plan, i) => (
                            <PricingCard key={i} {...plan} onPurchase={handlePurchase} />
                        ))}
                        {activeTab === 'smm' && smmPlans.map((plan, i) => (
                            <PricingCard key={i} {...plan} onPurchase={handlePurchase} />
                        ))}
                    </div>
                </div>
            </section>
            
            <section className="py-20 border-t border-[#333] bg-[#0a0a0a]">
                <div className="container mx-auto px-4 md:px-6 text-center">
                    <h2 className="text-3xl font-black uppercase mb-8">Need a Custom Package?</h2>
                    <a href="contact.html" className="btn">Contact Support</a>
                </div>
            </section>

            <CalendlyPopup />
            <ChatBot />
            <ScrollToTop />
            <Footer />
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <ServicesApp />
  </ErrorBoundary>
);