// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black text-white">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload Page</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function ResumeApp() {
    const handlePrint = () => {
        window.print();
    };

    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <div className="no-print">
                <Navigation activePage="resume" />
            </div>

            <div className="container mx-auto px-4 md:px-6 py-20">
                <div className="max-w-4xl mx-auto bg-white text-black p-8 md:p-16 shadow-2xl relative">
                    <button 
                        onClick={handlePrint}
                        className="absolute top-8 right-8 bg-black text-white px-4 py-2 text-xs font-bold uppercase hover:bg-[#00ff88] hover:text-black transition-colors no-print"
                    >
                        <div className="flex items-center gap-2">
                            <div className="icon-printer"></div> Print / PDF
                        </div>
                    </button>

                    {/* Header */}
                    <div className="border-b-2 border-black pb-8 mb-8">
                        <h1 className="text-5xl font-black uppercase tracking-tighter mb-2">Rudraksh Sharma</h1>
                        <p className="text-xl font-mono text-gray-600 mb-6">Digital Marketing Strategist & Creative Designer</p>
                        
                        <div className="flex flex-wrap gap-6 text-sm font-bold">
                            <div className="flex items-center gap-2">
                                <div className="icon-mail"></div> info.itsboyrudra@gmail.com
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="icon-phone"></div> +91 78783 83739
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="icon-map-pin"></div> India (Remote Global)
                            </div>
                        </div>
                    </div>

                    {/* Summary */}
                    <div className="mb-12">
                        <h2 className="text-2xl font-black uppercase mb-4 border-l-4 border-black pl-4">Professional Summary</h2>
                        <p className="text-gray-700 leading-relaxed">
                            Results-oriented Digital Marketer with 3+ years of experience managing high-budget Meta Ads campaigns and creating viral YouTube thumbnails. Specialized in data-driven creative testing and scaling strategies. Proven track record of improving ROAS by 3x and CTR by 150% for e-commerce brands and content creators.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                        {/* Left Column */}
                        <div className="md:col-span-2 space-y-10">
                            <div>
                                <h2 className="text-2xl font-black uppercase mb-6 border-l-4 border-black pl-4">Experience</h2>
                                
                                <div className="mb-8">
                                    <div className="flex justify-between items-baseline mb-2">
                                        <h3 className="text-xl font-bold">Lead Media Buyer & Strategist</h3>
                                        <span className="font-mono text-sm text-gray-500">2024 - Present</span>
                                    </div>
                                    <div className="italic text-gray-600 mb-3">Freelance / Agency Partner</div>
                                    <ul className="list-disc ml-5 space-y-2 text-gray-700 text-sm">
                                        <li>Managed over $50k in monthly ad spend across Meta platforms for e-commerce clients.</li>
                                        <li>Implemented the 3:2:2 creative testing method, reducing CPA by 40% in Q1 2025.</li>
                                        <li>Designed end-to-end sales funnels including ad creatives, copy, and landing page optimization.</li>
                                    </ul>
                                </div>

                                <div className="mb-8">
                                    <div className="flex justify-between items-baseline mb-2">
                                        <h3 className="text-xl font-bold">Social Media Manager & Designer</h3>
                                        <span className="font-mono text-sm text-gray-500">2023 - 2024</span>
                                    </div>
                                    <div className="italic text-gray-600 mb-3">Various Creators</div>
                                    <ul className="list-disc ml-5 space-y-2 text-gray-700 text-sm">
                                        <li>Designed 500+ YouTube thumbnails achieving an average CTR of 12%.</li>
                                        <li>Grew client Instagram accounts from 0 to 10k followers using organic Reels strategies.</li>
                                        <li>Analyzed retention metrics to optimize video pacing and content structure.</li>
                                    </ul>
                                </div>
                            </div>

                            <div>
                                <h2 className="text-2xl font-black uppercase mb-6 border-l-4 border-black pl-4">Key Projects</h2>
                                <div className="grid grid-cols-1 gap-4">
                                    <div className="bg-gray-50 p-4 border border-gray-200">
                                        <h4 className="font-bold">E-commerce Summer Sale Scale</h4>
                                        <p className="text-xs text-gray-600 mt-1">Scaled daily spend from $100 to $1,000 while maintaining 4x ROAS using CBO and dynamic creatives.</p>
                                    </div>
                                    <div className="bg-gray-50 p-4 border border-gray-200">
                                        <h4 className="font-bold">Tech Channel Rebrand</h4>
                                        <p className="text-xs text-gray-600 mt-1">Overhauled thumbnail strategy for 100k+ sub channel, resulting in 2M+ views in first month.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Right Column */}
                        <div className="space-y-10">
                            <div>
                                <h2 className="text-2xl font-black uppercase mb-6 border-l-4 border-black pl-4">Skills</h2>
                                <div className="flex flex-wrap gap-2">
                                    {['Meta Ads Manager', 'Photoshop', 'Canva Pro', 'Copywriting', 'Data Analysis', 'Video Editing', 'A/B Testing', 'Google Analytics', 'SEO'].map(skill => (
                                        <span key={skill} className="bg-black text-white px-3 py-1 text-xs font-bold uppercase">{skill}</span>
                                    ))}
                                </div>
                            </div>

                            <div>
                                <h2 className="text-2xl font-black uppercase mb-6 border-l-4 border-black pl-4">Education</h2>
                                <div>
                                    <h3 className="font-bold">Digital Marketing Certification</h3>
                                    <div className="text-sm text-gray-600">Meta Blueprint / Google</div>
                                    <div className="text-xs text-gray-500 mt-1">2023</div>
                                </div>
                                <div className="mt-4">
                                    <h3 className="font-bold">High School Diploma</h3>
                                    <div className="text-sm text-gray-600">Commerce Stream</div>
                                    <div className="text-xs text-gray-500 mt-1">In Progress (Student)</div>
                                </div>
                            </div>

                            <div>
                                <h2 className="text-2xl font-black uppercase mb-6 border-l-4 border-black pl-4">Languages</h2>
                                <div className="space-y-2 text-sm">
                                    <div className="flex justify-between">
                                        <span>English</span>
                                        <span className="font-bold">Professional</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>Hindi</span>
                                        <span className="font-bold">Native</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="no-print">
                <Footer />
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <ResumeApp />
  </ErrorBoundary>
);