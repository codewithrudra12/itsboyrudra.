function RefundApp() {
    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <NativeAds />
            <Navigation activePage="home" />
            <div className="container mx-auto px-4 md:px-6 py-20 max-w-4xl">
                <h1 className="text-4xl font-black uppercase mb-8 text-[#00ff88]">Refund Policy</h1>
                <div className="space-y-6 text-gray-300">
                    <div className="bg-red-900/20 border border-red-500 p-4 mb-8">
                        <p className="font-bold text-red-500">STRICT NO-REFUND POLICY FOR SERVICES RENDERED</p>
                    </div>
                    <h2 className="text-xl font-bold text-white mt-8">1. General Policy</h2>
                    <p>Due to the nature of digital services and creative work, we do not offer refunds once work has commenced or files have been delivered. By purchasing our services, you acknowledge and agree to this policy.</p>
                    <h2 className="text-xl font-bold text-white mt-8">2. Cancellations</h2>
                    <p>You may cancel a monthly retainer service with 30 days written notice. No pro-rated refunds are given for the current billing cycle.</p>
                    <h2 className="text-xl font-bold text-white mt-8">3. Revisions</h2>
                    <p>We offer revisions as stated in each package to ensure your satisfaction. Dissatisfaction with design style after revisions does not qualify for a refund.</p>
                    <h2 className="text-xl font-bold text-white mt-8">4. Exceptions</h2>
                    <p>In the unlikely event that we are unable to deliver the service at all due to our own constraints, a full refund will be issued.</p>
                </div>
            </div>
            <ChatBot />
            <ScrollToTop />
            <Footer />
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<RefundApp />);