// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black text-white">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload Page</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function TestimonialSlider() {
    const [currentIndex, setCurrentIndex] = React.useState(0);
    const testimonials = [
        {
            name: "Sarah Jenkins",
            role: "E-commerce Owner",
            quote: "Rudraksh's Meta Ads strategy completely turned our ROAS around. We went from breaking even to 3x returns in just two months.",
            image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
            rating: 5
        },
        {
            name: "Mike Chen",
            role: "Tech YouTuber",
            quote: "The thumbnails are insane. My CTR jumped from 4% to 9% on the first video we updated. Highly recommended for any serious creator.",
            image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
            rating: 5
        },
        {
            name: "Elena Rodriguez",
            role: "Marketing Agency",
            quote: "Professional, timely, and data-driven. The dashboard reporting makes it so easy to see where our budget is going.",
            image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
            rating: 4
        },
        {
            name: "David Kim",
            role: "SaaS Founder",
            quote: "The ad copy testing framework they use is brilliant. We found winning angles we never would have thought of ourselves.",
            image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
            rating: 5
        },
        {
            name: "Anita Roy",
            role: "Boutique Owner",
            quote: "Handling my Instagram was a headache until Rudraksh took over. Now I get consistent posts and my engagement has doubled.",
            image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
            rating: 5
        }
    ];

    React.useEffect(() => {
        const interval = setInterval(() => {
            setCurrentIndex((prev) => (prev + 1) % testimonials.length);
        }, 5000);
        return () => clearInterval(interval);
    }, [testimonials.length]);

    const nextSlide = () => setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    const prevSlide = () => setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);

    return (
        <div className="relative max-w-4xl mx-auto">
            <div className="overflow-hidden">
                <div 
                    className="flex transition-transform duration-500 ease-in-out" 
                    style={{ transform: `translateX(-${currentIndex * 100}%)` }}
                >
                    {testimonials.map((t, i) => (
                        <div key={i} className="w-full flex-shrink-0 px-4">
                            <TestimonialCard {...t} />
                        </div>
                    ))}
                </div>
            </div>
            
            <button 
                onClick={prevSlide}
                className="absolute top-1/2 -left-4 md:-left-12 transform -translate-y-1/2 bg-[#333] text-white p-3 rounded-full hover:bg-[#00ff88] hover:text-black transition-colors"
            >
                <div className="icon-chevron-left"></div>
            </button>
            <button 
                onClick={nextSlide}
                className="absolute top-1/2 -right-4 md:-right-12 transform -translate-y-1/2 bg-[#333] text-white p-3 rounded-full hover:bg-[#00ff88] hover:text-black transition-colors"
            >
                <div className="icon-chevron-right"></div>
            </button>
            
            <div className="flex justify-center gap-2 mt-8">
                {testimonials.map((_, i) => (
                    <button 
                        key={i}
                        onClick={() => setCurrentIndex(i)}
                        className={`w-2 h-2 rounded-full transition-all ${currentIndex === i ? 'bg-[#00ff88] w-8' : 'bg-gray-700'}`}
                    ></button>
                ))}
            </div>
        </div>
    );
}

function App() {
  return (
    <div className="bg-[#050505] min-h-screen">
      <Security />
      <NativeAds />
      <Navigation activePage="home" />
      
      <main>
        {/* Hero Section */}
        <HeroSlider />
        
        {/* Mindset Section */}
        <MindsetSection />
        
        {/* Services Section */}
        <section className="py-24 border-b border-[#333]">
            <div className="container mx-auto px-4 md:px-6">
                <div className="mb-16 md:flex justify-between items-end">
                    <div>
                        <h2 className="text-[#00ff88] mb-2 tracking-widest text-sm">What We Do</h2>
                        <h3 className="text-4xl md:text-5xl font-black uppercase">Our Services</h3>
                    </div>
                    <div className="hidden md:block w-1/3 h-px bg-[#333] mb-4"></div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <ServiceCard 
                        title="Meta Ads"
                        icon="icon-megaphone"
                        description="Data-driven ad campaigns designed to scale businesses. From creative strategy to detailed targeting and analytics."
                        tags={['Facebook', 'Instagram', 'Strategy', 'Scaling']}
                        link="services.html"
                    />
                    <ServiceCard 
                        title="YouTube Thumbnails"
                        icon="icon-image"
                        description="High CTR thumbnails tailored for creators. A/B testing variations and psychology-based designs."
                        tags={['Design', 'CTR', 'Branding', 'Growth']}
                        link="services.html"
                    />
                    <div className="relative group">
                        <ServiceCard 
                            title="Social Media Manager"
                            icon="icon-smartphone"
                            description="Full management of your Instagram/Facebook. Posts, Reels, and growth strategy. Perfect for busy founders."
                            tags={['IG Growth', 'Scheduling', 'Reels', 'Engagement']}
                            link="services.html"
                        />
                        <div className="absolute top-0 right-0 bg-blue-600 text-white text-[10px] font-bold px-2 py-1 uppercase tracking-wider shadow-lg transform translate-x-2 -translate-y-2 z-10">
                            New
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        {/* Testimonials */}
        <section className="py-24 bg-[#0a0a0a]">
            <div className="container mx-auto px-4 md:px-6">
                 <div className="mb-16 text-center">
                    <h2 className="text-[#00ff88] mb-2 tracking-widest text-sm">Testimonials</h2>
                    <h3 className="text-4xl font-black uppercase">Client Stories</h3>
                </div>
                
                <TestimonialSlider />
            </div>
        </section>
        
        <CalendlyPopup />
        <CookieConsent />
        <ChatBot />
        <ScrollToTop />
      </main>
      
      <Footer />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);