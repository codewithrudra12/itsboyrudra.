function PrivacyApp() {
    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <Navigation activePage="home" />
            <div className="container mx-auto px-4 md:px-6 py-20 max-w-4xl">
                <h1 className="text-4xl font-black uppercase mb-8 text-[#00ff88]">Privacy Policy</h1>
                <div className="space-y-6 text-gray-300">
                    <p>Your privacy is important to us. It is Rudraksh Sharma's policy to respect your privacy regarding any information we may collect from you across our website.</p>
                    
                    <h2 className="text-xl font-bold text-white mt-8">Information We Collect</h2>
                    <p>We may ask for personal information, such as your name, email, phone number, and payment details, when you subscribe to our newsletter, request a service, or contact us. We collect it by fair and lawful means, with your knowledge and consent.</p>
                    
                    <h2 className="text-xl font-bold text-white mt-8">How We Use Your Data</h2>
                    <ul className="list-disc ml-6 space-y-2">
                        <li>To provide and operate our services.</li>
                        <li>To process your transactions and manage your orders.</li>
                        <li>To communicate with you, including responding to your comments, questions, and requests.</li>
                        <li>To send you technical notices, updates, security alerts, and support and administrative messages.</li>
                    </ul>
                    
                    <h2 className="text-xl font-bold text-white mt-8">Data Protection & Sharing</h2>
                    <p>We do not share any personally identifying information publicly or with third-parties, except when required to by law. We retain collected information for as long as necessary to provide you with your requested service. What data we store, we’ll protect within commercially acceptable means to prevent loss and theft, as well as unauthorized access, disclosure, copying, use or modification.</p>
                    
                    <h2 className="text-xl font-bold text-white mt-8">Cookies</h2>
                    <p>We use cookies to help you personalize your online experience. You have the ability to accept or decline cookies. If you choose to decline cookies, you may not be able to fully experience the interactive features of our services.</p>
                </div>
            </div>
            <Footer />
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<PrivacyApp />);