// Important: DO NOT remove this `ErrorBoundary` component.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black text-white">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload Page</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function ThumbnailsApp() {
    const [category, setCategory] = React.useState('All');
    
    // Using the assets provided in the recent file list as thumbnail examples
    const allThumbnails = [
        { id: 1, title: "Viral Gaming Challenge", category: "Gaming", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/5bb4a7d6-066c-462a-91c7-0b8a9227f4ac.Untitled" },
        { id: 2, title: "Tech Review 2026", category: "Tech", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/0e53a5d0-0cb9-4ec3-9633-3420b44439cb.Untitled" },
        { id: 3, title: "Crypto Boom Explained", category: "Finance", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/72ad46dd-e534-4e66-936b-7ae132f0aa9f.Untitled" },
        { id: 4, title: "MrBeast Style Challenge", category: "Entertainment", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/3353eb60-c156-4037-b3b3-8683026f0489.Untitled" },
        { id: 5, title: "Ultimate Fitness Guide", category: "Lifestyle", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/deb3f4d8-1625-4a0f-8c97-05b5cb5623cc.Untitled" },
        { id: 6, title: "ASMR Relaxing", category: "Lifestyle", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/22f27858-12f2-4b27-b70f-28849e20e1a7.Untitled" },
        { id: 7, title: "Coding Tutorial React", category: "Tech", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/fa0a2df7-0192-44ec-8bdd-1240cb4e51a4.Untitled" },
        { id: 8, title: "Stock Market Crash", category: "Finance", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/09a676fa-23ea-41d7-a928-09d72be87277.Untitled" },
        { id: 9, title: "Travel Vlog Japan", category: "Vlog", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/fd4bf74a-64fb-46f8-ba27-1f72225699ac.Untitled" },
        { id: 10, title: "Horror Game Playthrough", category: "Gaming", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/7b151d6e-d40b-4395-a45a-cbdfeffc79d3.Untitled" },
        { id: 11, title: "Productivity Hacks", category: "Lifestyle", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/22e9c749-9aa4-4aa8-b67e-a51f861db1f5.Untitled" },
        { id: 12, title: "AI Revolution", category: "Tech", url: "https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/26ed7763-5f45-44b2-a03e-adf0ccb255cf.Untitled" }
    ];

    const categories = ['All', 'Gaming', 'Tech', 'Finance', 'Lifestyle', 'Entertainment', 'Vlog'];

    const filteredThumbnails = category === 'All' 
        ? allThumbnails 
        : allThumbnails.filter(t => t.category === category);

    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <Navigation activePage="thumbnails" />
            
            <header className="py-20 border-b border-[#333]">
                <div className="container mx-auto px-4 md:px-6 text-center">
                    <h1 className="text-5xl md:text-7xl font-black uppercase mb-6 tracking-tighter">
                        My <span className="text-[#00ff88]">Thumbnails</span>
                    </h1>
                    <p className="text-gray-400 max-w-2xl mx-auto text-lg">
                        A curated collection of high-CTR designs. Click to view full details.
                    </p>
                </div>
            </header>

            <section className="py-12 border-b border-[#333]">
                <div className="container mx-auto px-4 md:px-6">
                    <div className="flex flex-wrap justify-center gap-4">
                        {categories.map(cat => (
                            <button 
                                key={cat}
                                onClick={() => setCategory(cat)}
                                className={`px-6 py-2 text-sm font-bold uppercase tracking-wider border transition-all ${category === cat ? 'bg-[#00ff88] text-black border-[#00ff88]' : 'text-gray-400 border-[#333] hover:border-white'}`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                </div>
            </section>

            <section className="py-20">
                <div className="container mx-auto px-4 md:px-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {filteredThumbnails.map((thumb) => (
                            <div key={thumb.id} className="group relative bg-[#121212] border border-[#333] overflow-hidden hover:border-[#00ff88] transition-colors">
                                <div className="aspect-video overflow-hidden relative">
                                    <img 
                                        src={thumb.url} 
                                        alt={thumb.title} 
                                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                    />
                                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-6 text-center">
                                        <h3 className="text-xl font-bold uppercase text-white mb-2">{thumb.title}</h3>
                                        <span className="text-[#00ff88] text-xs font-mono uppercase tracking-widest">{thumb.category}</span>
                                    </div>
                                </div>
                                <div className="p-4 border-t border-[#333] flex justify-between items-center">
                                    <span className="text-xs text-gray-500 font-mono">ID: #{thumb.id}</span>
                                    <button className="text-white hover:text-[#00ff88] transition-colors">
                                        <div className="icon-maximize-2"></div>
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
            
            <Footer />
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <ThumbnailsApp />
  </ErrorBoundary>
);