function InstagramDummyApp() {
    const posts = [
        "https://images.unsplash.com/photo-1554080353-a576cf803bda?auto=format&fit=crop&q=80&w=400",
        "https://images.unsplash.com/photo-1561214115-f2f134cc4912?auto=format&fit=crop&q=80&w=400",
        "https://images.unsplash.com/photo-1492633423870-43d1cd2775eb?auto=format&fit=crop&q=80&w=400",
        "https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&q=80&w=400",
        "https://images.unsplash.com/photo-1529139574466-a302c27e3844?auto=format&fit=crop&q=80&w=400",
        "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80&w=400",
        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=400",
        "https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&q=80&w=400",
        "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=400"
    ];

    return (
        <div className="max-w-4xl mx-auto min-h-screen bg-black text-white">
            {/* Nav */}
            <div className="flex justify-between items-center p-4 border-b border-gray-800 sticky top-0 bg-black z-10">
                <div className="font-bold text-xl font-serif italic">Instagram</div>
                <div className="flex gap-4">
                    <button className="bg-[#00ff88] text-black px-4 py-1.5 rounded text-sm font-bold" onClick={() => window.location.href='services.html'}>
                        Back to Portfolio
                    </button>
                </div>
            </div>

            {/* Header */}
            <div className="p-4 md:p-8 flex items-start gap-8 border-b border-gray-800">
                <div className="w-20 h-20 md:w-36 md:h-36 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 p-[2px] shrink-0">
                    <div className="w-full h-full rounded-full border-2 border-black overflow-hidden">
                        <img src="https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/3a7c0c49-23a1-46ae-81cc-04ddaeb0421c.png" className="w-full h-full object-cover" />
                    </div>
                </div>
                <div className="flex-1">
                    <div className="flex items-center gap-4 mb-4">
                        <h2 className="text-xl font-light">rudra.growth</h2>
                        <button className="bg-white text-black px-4 py-1.5 rounded font-bold text-sm">Follow</button>
                        <button className="bg-gray-800 px-4 py-1.5 rounded font-bold text-sm">Message</button>
                    </div>
                    <div className="flex gap-8 mb-4 text-sm md:text-base">
                        <div><span className="font-bold">142</span> posts</div>
                        <div><span className="font-bold">12.5k</span> followers</div>
                        <div><span className="font-bold">482</span> following</div>
                    </div>
                    <div>
                        <div className="font-bold">Rudraksh Sharma | SMM Expert</div>
                        <div className="text-gray-300 text-sm whitespace-pre-line">
                            🚀 Helping brands scale past $10k/mo
                            📈 Meta Ads & Viral Content
                            🎓 Student Hustler | 200+ Clients
                            👇 Book your strategy call
                            <a href="#" className="text-blue-400">linktr.ee/rudra</a>
                        </div>
                    </div>
                </div>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-3 gap-1 md:gap-4 p-1 md:p-4">
                {posts.map((src, i) => (
                    <div key={i} className="aspect-square bg-gray-900 group relative cursor-pointer overflow-hidden">
                        <img src={src} className="w-full h-full object-cover group-hover:opacity-75 transition-opacity" />
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity gap-4 text-white font-bold">
                            <div className="flex items-center"><div className="icon-heart fill-white mr-1"></div> {Math.floor(Math.random() * 500) + 100}</div>
                            <div className="flex items-center"><div className="icon-message-circle fill-white mr-1"></div> {Math.floor(Math.random() * 50) + 5}</div>
                        </div>
                    </div>
                ))}
            </div>
            
            <div className="p-8 text-center text-gray-500 text-sm">
                This is a simulated portfolio page demonstrating content curation style.
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<InstagramDummyApp />);