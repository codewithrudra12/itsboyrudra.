function DisclaimerApp() {
    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <NativeAds />
            <Navigation activePage="home" />
            <div className="container mx-auto px-4 md:px-6 py-20 max-w-4xl">
                <h1 className="text-4xl font-black uppercase mb-8 text-[#00ff88]">Disclaimer</h1>
                <div className="space-y-6 text-gray-300">
                    <h2 className="text-xl font-bold text-white mt-8">Earnings Disclaimer</h2>
                    <p>We make no guarantees regarding results or earnings. Past performance in ad campaigns or thumbnail CTR is not indicative of future results. Your success depends on many factors including your product, market, and budget.</p>
                    <h2 className="text-xl font-bold text-white mt-8">Third Party Links</h2>
                    <p>This website may contain links to third-party websites. We are not responsible for the content or practices of these sites.</p>
                </div>
            </div>
            <ChatBot />
            <ScrollToTop />
            <Footer />
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<DisclaimerApp />);