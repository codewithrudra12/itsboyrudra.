function FaqsApp() {
    const faqs = [
        { q: "What is your turnaround time?", a: "For thumbnails, it's typically 24-48 hours. For ad setup, it takes 3-5 days for initial strategy and launch." },
        { q: "Do you offer refunds?", a: "Please check our strict No-Refund Policy. Generally, once work starts, fees are non-refundable." },
        { q: "What payment methods do you accept?", a: "We accept PayPal and major credit cards via PayPal." },
        { q: "Can I upgrade my plan later?", a: "Yes, you can upgrade your service package at any time." }
    ];
    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            <NativeAds />
            <Navigation activePage="home" />
            <div className="container mx-auto px-4 md:px-6 py-20 max-w-4xl">
                <h1 className="text-4xl font-black uppercase mb-8 text-[#00ff88]">Frequently Asked Questions</h1>
                <div className="space-y-8">
                    {faqs.map((faq, i) => (
                        <div key={i} className="bg-[#121212] border border-[#333] p-6">
                            <h3 className="text-lg font-bold text-white mb-2">{faq.q}</h3>
                            <p className="text-gray-400">{faq.a}</p>
                        </div>
                    ))}
                </div>
            </div>
            <ChatBot />
            <ScrollToTop />
            <Footer />
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<FaqsApp />);