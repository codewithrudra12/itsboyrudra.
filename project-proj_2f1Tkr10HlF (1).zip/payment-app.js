class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black text-white">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload Page</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function PaymentApp() {
    const [planDetails, setPlanDetails] = React.useState(null);
    const [country, setCountry] = React.useState('Loading...');
    const [isIndia, setIsIndia] = React.useState(false);
    const [formData, setFormData] = React.useState({
        name: '', email: '', mobile: '', connectionReason: '', agreedToRefund: false,
        duration: '', customAmount: ''
    });
    const [captcha, setCaptcha] = React.useState({ num1: 0, num2: 0, answer: 0, userAns: '' });
    const [error, setError] = React.useState('');
    const [isSubmitting, setIsSubmitting] = React.useState(false);
    const [notification, setNotification] = React.useState({ show: false, message: '', type: '' });
    const [calculatedAmount, setCalculatedAmount] = React.useState(0);
    const [hoursPerDay, setHoursPerDay] = React.useState(8); // Default working hours per day

    React.useEffect(() => {
        // Parse Query Params
        const params = new URLSearchParams(window.location.search);
        const title = params.get('plan');
        const price = params.get('price');
        const type = params.get('type') || 'Standard';
        
        setPlanDetails({ title, price, type });

        // Detect Country via API
        fetch('https://ipapi.co/json/')
            .then(res => res.json())
            .then(data => {
                setCountry(data.country_name);
                if (data.country_code === 'IN') {
                    setIsIndia(true);
                } else {
                    setIsIndia(false);
                }
            })
            .catch(() => {
                setCountry('Unknown');
                setIsIndia(false); // Default to Global if failed
            });

        // Init Captcha
        const n1 = Math.floor(Math.random() * 10) + 1;
        const n2 = Math.floor(Math.random() * 10) + 1;
        setCaptcha({ num1: n1, num2: n2, answer: n1 + n2, userAns: '' });
    }, []);

    const isMetaAds = planDetails?.title?.toLowerCase().includes('meta') || false;

    // Show custom notification
    const showNotification = (message, type = 'info') => {
        setNotification({ show: true, message, type });
        setTimeout(() => {
            setNotification({ show: false, message: '', type: '' });
        }, 5000);
    };

    // Calculate Meta Ads amount
    React.useEffect(() => {
        if (isMetaAds && formData.duration) {
            const days = parseInt(formData.duration);
            const hoursPerDayNum = parseInt(hoursPerDay) || 8;
            
            if (days > 0 && hoursPerDayNum > 0) {
                // Calculate total hours
                const totalHours = days * hoursPerDayNum;
                
                // Calculate amount based on $20/hour
                const usdAmount = totalHours * 20;
                
                // Convert to INR if India (using approximate conversion rate)
                const inrAmount = usdAmount * 83; // Approx conversion rate
                
                const finalAmount = isIndia ? inrAmount : usdAmount;
                setCalculatedAmount(finalAmount);
                
                // Auto-fill the custom amount field with rounded value
                setFormData(prev => ({
                    ...prev,
                    customAmount: Math.round(finalAmount)
                }));
            }
        }
    }, [formData.duration, hoursPerDay, isIndia, isMetaAds]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (parseInt(captcha.userAns) !== captcha.answer) {
            setError('Incorrect Captcha.');
            return;
        }

        if (!formData.agreedToRefund) {
            setError('Please agree to the Refund Policy.');
            return;
        }

        if (isMetaAds && (!formData.duration || !formData.customAmount)) {
            setError('Please fill in duration and verify the calculated amount.');
            return;
        }

        setIsSubmitting(true);

        const targetFormspree = "https://formspree.io/f/mzddpwzd";
        
        try {
            // Prepare payment data
            const paymentData = {
                ...formData,
                plan: planDetails.title,
                price: isIndia ? 'QR Payment' : planDetails.price,
                countryDetected: country,
                calculatedAmount: calculatedAmount,
                currency: isIndia ? 'INR' : 'USD',
                hoursPerDay: hoursPerDay
            };

            await fetch(targetFormspree, {
                method: "POST",
                headers: { "Content-Type": "application/json", "Accept": "application/json" },
                body: JSON.stringify(paymentData)
            });

            if (!isIndia) {
                // For Global PayPal - redirect with amount
                const paypalAmount = calculatedAmount > 0 ? calculatedAmount : planDetails.price.replace('$', '');
                const paypalLink = `https://www.paypal.com/paypalme/itsboyrudra?amount=${paypalAmount}`;
                showNotification(`Redirecting to PayPal. Please pay $${paypalAmount}`, 'success');
                
                // Redirect after short delay
                setTimeout(() => {
                    window.location.href = paypalLink;
                }, 2000);
            } else {
                // For India - Show QR with amount
                showNotification(`Please scan the QR code and pay ₹${calculatedAmount}`, 'info');
                setIsSubmitting(false); // Stay on page to see QR
            }
        } catch (err) {
            setError("Network error.");
            setIsSubmitting(false);
            showNotification("Payment submission failed. Please try again.", 'error');
        }
    };

    if (!planDetails) return <div>Loading...</div>;

    return (
        <div className="bg-[#050505] min-h-screen pt-20">
            {/* Custom Notification */}
            {notification.show && (
                <div className={`fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg ${
                    notification.type === 'error' ? 'bg-red-900 border-red-700' : 
                    notification.type === 'success' ? 'bg-green-900 border-green-700' : 
                    'bg-blue-900 border-blue-700'
                } border`}>
                    <div className="flex items-center">
                        <span className="text-white">{notification.message}</span>
                        <button 
                            onClick={() => setNotification({ show: false, message: '', type: '' })} 
                            className="ml-4 text-gray-300 hover:text-white"
                        >
                            ✕
                        </button>
                    </div>
                </div>
            )}

            <Navigation activePage="services" />
            
            <section className="py-20">
                <div className="container mx-auto px-4 md:px-6 max-w-4xl">
                    <h1 className="text-3xl font-black uppercase mb-8 border-b border-[#333] pb-6">
                        Secure Checkout <span className="text-[#00ff88]">.</span>
                    </h1>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                        <div className="md:col-span-2">
                             <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-xs font-bold uppercase text-gray-500">Full Name</label>
                                        <input type="text" required className="input-field" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                                    </div>
                                    <div>
                                        <label className="text-xs font-bold uppercase text-gray-500">Mobile</label>
                                        <input type="tel" required className="input-field" value={formData.mobile} onChange={e => setFormData({...formData, mobile: e.target.value})} />
                                    </div>
                                </div>
                                
                                <div>
                                    <label className="text-xs font-bold uppercase text-gray-500">Email Address</label>
                                    <input type="email" required className="input-field" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
                                </div>

                                {isMetaAds && (
                                    <div className="bg-[#121212] p-4 border border-[#333]">
                                        <h4 className="text-[#00ff88] font-bold uppercase text-xs mb-4">Meta Ads Specifics</h4>
                                        <div className="grid grid-cols-2 gap-4 mb-4">
                                            <div>
                                                <label className="text-xs font-bold uppercase text-gray-500">Duration (Days)</label>
                                                <input 
                                                    type="number" 
                                                    required 
                                                    className="input-field" 
                                                    placeholder="e.g. 30" 
                                                    value={formData.duration} 
                                                    onChange={e => setFormData({...formData, duration: e.target.value})}
                                                    min="1"
                                                />
                                            </div>
                                            <div>
                                                <label className="text-xs font-bold uppercase text-gray-500">Hours Per Day</label>
                                                <select 
                                                    className="input-field"
                                                    value={hoursPerDay}
                                                    onChange={e => setHoursPerDay(e.target.value)}
                                                >
                                                    <option value="4">4 hours/day</option>
                                                    <option value="8">8 hours/day</option>
                                                    <option value="12">12 hours/day</option>
                                                    <option value="16">16 hours/day</option>
                                                    <option value="24">24 hours/day</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        {/* Calculated Amount Display */}
                                        <div className="bg-[#0a0a0a] p-3 border border-[#333] mb-4">
                                            <div className="flex justify-between items-center">
                                                <span className="text-xs text-gray-400">Calculated Amount:</span>
                                                <span className="text-lg font-bold text-[#00ff88]">
                                                    {isIndia ? '₹' : '$'}{calculatedAmount > 0 ? Math.round(calculatedAmount) : '0'}
                                                    <span className="text-xs text-gray-400 ml-2">
                                                        ({formData.duration || 0} days × {hoursPerDay} hours × {isIndia ? '₹1,660/hour' : '$20/hour'})
                                                    </span>
                                                </span>
                                            </div>
                                        </div>

                                        <div>
                                            <label className="text-xs font-bold uppercase text-gray-500">
                                                Final Amount to Pay ({isIndia ? 'INR' : 'USD'})
                                            </label>
                                            <input 
                                                type="number" 
                                                required 
                                                className="input-field" 
                                                placeholder={`Enter ${isIndia ? '₹' : '$'}${calculatedAmount > 0 ? Math.round(calculatedAmount) : 'amount'}`}
                                                value={formData.customAmount}
                                                onChange={e => setFormData({...formData, customAmount: e.target.value})}
                                                min="1"
                                            />
                                            <p className="text-xs text-gray-500 mt-1">
                                                Please verify the calculated amount above. You can adjust if needed.
                                            </p>
                                        </div>
                                    </div>
                                )}

                                <div>
                                    <label className="text-xs font-bold uppercase text-gray-500">Reason for Connection</label>
                                    <textarea required className="input-field h-24" placeholder="Your goals..." value={formData.connectionReason} onChange={e => setFormData({...formData, connectionReason: e.target.value})}></textarea>
                                </div>

                                {/* Custom Captcha */}
                                <div className="flex items-center gap-4 bg-[#121212] p-4 border border-[#333]">
                                    <div className="text-sm font-bold text-gray-400">Security: {captcha.num1} + {captcha.num2} = ?</div>
                                    <input type="number" required className="input-field w-20 text-center" value={captcha.userAns} onChange={e => setCaptcha({...captcha, userAns: e.target.value})} />
                                </div>

                                <div className="flex items-start gap-3">
                                    <input type="checkbox" required checked={formData.agreedToRefund} onChange={e => setFormData({...formData, agreedToRefund: e.target.checked})} className="mt-1" />
                                    <label className="text-xs text-gray-400">I agree to the Refund Policy. Digital services are non-refundable.</label>
                                </div>

                                {error && <div className="text-red-500 text-xs font-bold">{error}</div>}

                                <button type="submit" disabled={isSubmitting} className="btn btn-primary w-full">
                                    {isSubmitting ? 'Processing...' : (isIndia ? `Pay ₹${calculatedAmount > 0 ? Math.round(calculatedAmount) : ''}` : `Pay $${calculatedAmount > 0 ? Math.round(calculatedAmount) : ''}`)}
                                </button>
                             </form>
                        </div>

                        <div className="space-y-8">
                            <div className="bg-[#121212] p-6 border border-[#333]">
                                <h3 className="text-xl font-bold uppercase text-white mb-2">{planDetails.title}</h3>
                                <div className="text-[#00ff88] text-2xl font-mono mb-4">
                                    {isIndia ? 'Custom Pricing (₹)' : planDetails.price}
                                </div>
                                <div className="text-xs text-gray-500 uppercase border-t border-[#333] pt-4 mt-4">
                                    Detected Location: <span className="text-white font-bold">{country}</span><br />
                                    Currency: <span className="text-white font-bold">{isIndia ? 'Indian Rupees (₹)' : 'US Dollars ($)'}</span><br />
                                    Rate: <span className="text-white font-bold">{isIndia ? '₹1,660/hour' : '$20/hour'}</span>
                                </div>
                            </div>

                            {/* Payment Method Display */}
                            <div className="bg-[#121212] p-6 border border-[#333]">
                                <h3 className="text-sm font-bold uppercase text-gray-500 mb-4">Payment Method</h3>
                                {isIndia ? (
                                    <div className="text-center">
                                        <div className="mb-4 bg-white p-2 inline-block rounded">
                                            <img src="https://app.trickle.so/storage/public/images/usr_19a910aaa0008001/f4f91583-77f1-4254-9eff-b4cde5fbae2a.Untitled" alt="Pay via QR" className="w-48 h-48 object-contain" />
                                        </div>
                                        <p className="text-xs text-gray-400 mb-2">Scan via UPI / PayTM</p>
                                        {calculatedAmount > 0 && (
                                            <div className="text-[#00ff88] text-lg font-bold">
                                                Amount: ₹{Math.round(calculatedAmount)}
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div className="text-center space-y-4">
                                        <div className="bg-white text-blue-900 font-bold italic py-2 px-4 rounded text-xl">PayPal</div>
                                        <p className="text-xs text-gray-400">Secure International Payment</p>
                                        {calculatedAmount > 0 && (
                                            <div className="text-[#00ff88] text-lg font-bold">
                                                Amount: ${Math.round(calculatedAmount)}
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <Footer />
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <PaymentApp />
  </ErrorBoundary>
);